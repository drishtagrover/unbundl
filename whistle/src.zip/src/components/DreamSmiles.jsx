import { useEffect, useRef, useState } from 'react';
import '../cssFiles/DreamSmiles.css';
// import predictableSmile from '..assets/predictable-smile';
// import priceIcon from '../assets/price.svg';

const MARQUEE_ITEMS = [
  ' Our biggest launch benefit',
  ' Free teeth scans worth ₹500',
  ' Free Orthodontic consultation worth ₹750',
  ' Our biggest launch benefit',
  ' Free teeth scans worth ₹500',
  ' Free Orthodontic consultation worth ₹750',
  ' Our biggest launch benefit',
  ' Free teeth scans worth ₹500',
];

const BENEFITS = [
  {
    // icon: predictableSmile,
    title: 'Predictable smile',
    description:
      'An innovative 3D modeling lets Dr. simulate your treatment plan so you can visualize your perfect smile before it happens.',
  },
  {
    // icon: priceIcon,
    title: 'Transparent Pricing',
    description:
      'Everything is included — from scans to aligners. No surprise charges. Know exactly what your treatment costs from day one.',
  },
];

export default function DreamSmiles() {
  const sectionRef = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.12 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <>
      {/* Green Marquee Strip */}
      <div className="marquee-strip">
        <div className="marquee-track">
          {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((item, i) => (
            <span key={i} className="marquee-item">
              {item}
              <span className="marquee-sep">|</span>
            </span>
          ))}
        </div>
      </div>

      {/* Dream Smiles Section */}
      <section className="dream" ref={sectionRef}>
        <div className="dream__inner">
          {/* Left: Headline + body */}
          <div className={`dream__left ${visible ? 'dream__left--visible' : ''}`}>
            <h2 className="dream__heading">
              Dream smiles<br />
              achieved secretly
            </h2>
            <p className="dream__body">
              Experience the superior quality of our 97.5% Invisibly worn treatment in
              an easy 3 step process. With over 10,000+ satisfied customers, Whistle
              is redefining smile transformations across India.
            </p>
            <p className="dream__body">
              The philosophy of Whistle is to make Clear Aligners highly compliant,
              predictable, and accessible so outcomes are excellent at all price points.
            </p>
            <div className="dream__icons">
              <div className="dream__icon-row">
                <span className="dream__check">✓</span>
                <span>Invisible aligners</span>
              </div>
              <div className="dream__icon-row">
                <span className="dream__check">✓</span>
                <span>Doctor supervised</span>
              </div>
            </div>
          </div>

          {/* Right: Whistle Aligners product card */}
          <div className={`dream__right ${visible ? 'dream__right--visible' : ''}`}>
            <div className="dream__card">
              <div className="dream__card-header">
                <div>
                  <p className="dream__card-label">Whistle Aligners</p>
                  <div className="dream__card-price-row">
                    <span className="dream__card-original">Starting at</span>
                  </div>
                  <div className="dream__card-amount">
                    <span className="dream__card-currency">₹</span>
                    <span className="dream__card-number">47,999</span>
                  </div>
                  <div className="dream__card-emi">
                    <span className="dream__card-emi-label">EMI starting at </span>
                    <span className="dream__card-emi-amount">₹2,999/mo</span>
                  </div>
                </div>
                <div className="dream__card-aligner-img">
                  <img
                    src="https://picsum.photos/seed/aligner/80/80"
                    alt="Aligner"
                    className="dream__aligner"
                  />
                </div>
              </div>

              {/* Benefit rows */}
              <div className="dream__card-divider" />
              {BENEFITS.map((b, i) => (
                <div
                  key={i}
                  className={`dream__benefit-card ${visible ? 'dream__benefit-card--visible' : ''}`}
                  style={{ transitionDelay: `${0.2 + i * 0.12}s` }}
                >
                  {b.icon && <img src={b.icon} alt={b.title} className="dream__benefit-icon" />}
                  <div>
                    <p className="dream__benefit-title">{b.title}</p>
                    <p className="dream__benefit-desc">{b.description}</p>
                  </div>
                </div>
              ))}

              <button className="dream__learn-btn">Learn More →</button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}