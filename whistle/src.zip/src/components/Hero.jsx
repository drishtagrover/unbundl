import { useState } from 'react';
import '../cssFiles/Hero.css'

export default function Hero() {
  const [hasGaps, setHasGaps] = useState(null);
  const [pincode, setPincode] = useState('');
  const [name, setName] = useState('');

  return (
    <section className="hero">
      <div className="hero__inner">
        {/* Left content */}
        <div className="hero__content">
          <h1 className="hero__heading">
            Invisible Aligners for a dream smile
          </h1>
          <p className="hero__sub">
            Book a Scan and avail a free <br />
            Orthodontist Consult{' '}
            <span className="hero__sub--strike">worth ₹800</span>
          </p>

          {/* Form card */}
          <div className="hero__form-card">
            <p className="hero__form-label">Do you have Teeth Gaps or Crooked Teeth?</p>
            <div className="hero__radio-group">
              <label className={`hero__radio ${hasGaps === true ? 'hero__radio--active' : ''}`}>
                <input
                  type="radio"
                  name="gaps"
                  value="yes"
                  checked={hasGaps === true}
                  onChange={() => setHasGaps(true)}
                />
                <span className="hero__radio-dot" />
                Yes
              </label>
              <label className={`hero__radio ${hasGaps === false ? 'hero__radio--active' : ''}`}>
                <input
                  type="radio"
                  name="gaps"
                  value="no"
                  checked={hasGaps === false}
                  onChange={() => setHasGaps(false)}
                />
                <span className="hero__radio-dot" />
                No
              </label>
            </div>

            <div className="hero__inputs">
              <input
                className="hero__input"
                type="text"
                placeholder="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <input
                className="hero__input"
                type="text"
                placeholder="Pin Code"
                value={pincode}
                onChange={(e) => setPincode(e.target.value)}
              />
              <button className="hero__submit">Book a Free Scan</button>
            </div>
          </div>

          {/* Clove Dental banner */}
          <div className="hero__banner">
            <div className="hero__banner-text">
              <p className="hero__banner-title">
                Book a Free 3D Teeth Scan and Orthodontist Consult in a
                <br />Clove Dental Clinic near you.
              </p>
            </div>
            <div className="hero__banner-right">
              <div className="hero__clove-badge">
                <span className="hero__clove-c">c</span>
                <span className="hero__clove-text">clove<br/>dental</span>
              </div>
              <a href="#" className="hero__find-link">Find Clinic →</a>
            </div>
          </div>
        </div>

        {/* Right image */}
        <div className="hero__image-wrap">
          <img
            src="https://picsum.photos/seed/smile1/480/560"
            alt="Woman with perfect smile"
            className="hero__photo"
          />
        </div>
      </div>
    </section>
  );
}