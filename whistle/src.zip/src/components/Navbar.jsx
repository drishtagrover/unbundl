import '../cssFiles/Navbar.css';
import whistleLogo from '../assets/whistle-logo.png';

export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar__inner">
        <a href="#" className="navbar__brand">
          <img src={whistleLogo} alt="Whistle" className="navbar__logo" />
          <span className="navbar__name">whistle</span>
        </a>
        <ul className="navbar__links">
          <li><a href="#">Home</a></li>
          <li><a href="#">Book a Free Scan</a></li>
          <li><a href="#">How it Works</a></li>
          <li><a href="#">Range of Aligners</a></li>
          <li><a href="#">Aligners vs Braces</a></li>
          <li><a href="#">FAQs</a></li>
        </ul>
        <button className="navbar__cta">Book a Free Scan</button>
      </div>
    </nav>
  );
}