import { useEffect, useRef, useState } from 'react';
import '../cssFiles/Results.css';

const RESULTS = [
  {
    before: 'https://picsum.photos/seed/teeth1b/220/200',
    after: 'https://picsum.photos/seed/teeth1a/220/200',
    label: 'Crowded',
    subLabel: 'Teeth too Crowded',
  },
  {
    before: 'https://picsum.photos/seed/teeth2b/220/200',
    after: 'https://picsum.photos/seed/teeth2a/220/200',
    label: 'Plain',
    subLabel: 'Teeth too Plain',
  },
  {
    before: 'https://picsum.photos/seed/teeth3b/220/200',
    after: 'https://picsum.photos/seed/teeth3a/220/200',
    label: 'Crooked',
    subLabel: 'Teeth too Crooked',
  },
  {
    before: 'https://picsum.photos/seed/teeth4b/220/200',
    after: 'https://picsum.photos/seed/teeth4a/220/200',
    label: 'Overbite',
    subLabel: 'Teeth too Overbite',
  },
  {
    before: 'https://picsum.photos/seed/teeth5b/220/200',
    after: 'https://picsum.photos/seed/teeth5a/220/200',
    label: 'Gap',
    subLabel: 'Teeth has Gap',
  },
  {
    before: 'https://picsum.photos/seed/teeth6b/220/200',
    after: 'https://picsum.photos/seed/teeth6a/220/200',
    label: 'Underbite',
    subLabel: 'Teeth too Underbite',
  },
  {
    before: 'https://picsum.photos/seed/teeth7b/220/200',
    after: 'https://picsum.photos/seed/teeth7a/220/200',
    label: 'Open bite',
    subLabel: 'Teeth Open Bite',
  },
  {
    before: 'https://picsum.photos/seed/teeth8b/220/200',
    after: 'https://picsum.photos/seed/teeth8a/220/200',
    label: 'Fixing Smile',
    subLabel: 'Teeth too Misaligned',
  },
];

function ResultCard({ item, index, isVisible }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      className={`result-card ${isVisible ? 'result-card--visible' : ''}`}
      style={{ transitionDelay: `${index * 0.07}s` }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Image with before/after flip on hover */}
      <div className="result-card__img-wrap">
        <img
          src={hovered ? item.after : item.before}
          alt={`${item.label} result`}
          className="result-card__img"
        />
        <div className="result-card__badge">
          {hovered ? 'After' : 'Before'}
        </div>
      </div>

      <div className="result-card__info">
        <p className="result-card__label">{item.label}</p>
        <p className="result-card__sublabel">{item.subLabel}</p>
        <p className="result-card__treatment">Treatment time: 6–8 months</p>
      </div>
    </div>
  );
}

export default function Results() {
  const sectionRef = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="results" ref={sectionRef}>
      <div className="results__inner">
        <h2 className={`results__heading ${visible ? 'results__heading--visible' : ''}`}>
          Results You'll Love
        </h2>

        <div className="results__grid">
          {RESULTS.map((item, i) => (
            <ResultCard key={i} item={item} index={i} isVisible={visible} />
          ))}
        </div>
      </div>
    </section>
  );
}